(()=>{'use strict';
const selector='.hero-capabilities a[href]';
function anchorAt(x,y){for(const a of document.querySelectorAll(selector)){const r=a.getBoundingClientRect();if(r.width && r.height && x>=r.left && x<=r.right && y>=r.top && y<=r.bottom) return a;}return null;}
// Capture before legacy shell/animation listeners. Handles clicks that hit overlapping visual layers.
document.addEventListener('click',function(e){const match=e.target.closest?.(selector) || (e.detail>0 ? anchorAt(e.clientX,e.clientY) : null);if(!match)return;const url=match.getAttribute('href');if(!url||!url.startsWith('/')||url.startsWith('//'))return; if(e.defaultPrevented)return;e.preventDefault();e.stopImmediatePropagation();window.location.assign(url);},true);
})();
