(()=>{'use strict';
const SVG='<svg viewBox="0 0 192 192" width="100%" height="100%" focusable="false" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"><g class="pr41-pet-ring"><path fill="#0c44fb" d="M 123.00 14.00 C 121.55 11.54 115.11 10.44 108.00 10.00 C 100.89 9.56 83.28 8.97 74.00 11.00 C 64.72 13.03 51.25 19.36 44.00 24.00 C 36.75 28.64 28.64 36.91 24.00 43.00 C 19.36 49.09 14.46 57.30 12.00 66.00 C 9.54 74.70 6.71 93.72 7.00 103.00 C 7.29 112.28 10.96 123.19 14.00 130.00 C 17.05 136.81 24.38 148.41 28.00 150.00 C 31.62 151.59 39.15 145.06 39.00 141.00 C 38.85 136.94 29.32 127.36 27.00 122.00 C 24.68 116.64 23.29 110.67 23.00 104.00 C 22.71 97.33 23.26 82.96 25.00 76.00 C 26.74 69.04 29.64 62.38 35.00 56.00 C 40.37 49.62 53.45 36.64 62.00 32.00 C 70.56 27.36 85.88 24.73 94.00 24.00 C 102.12 23.27 113.80 28.45 118.00 27.00 C 122.20 25.55 124.45 16.46 123.00 14.00 Z"/><path fill="#0b43fc" d="M 166.00 44.00 C 162.66 42.70 154.44 48.66 154.00 52.00 C 153.56 55.34 160.82 61.34 163.00 67.00 C 165.18 72.66 168.28 85.06 169.00 91.00 C 169.72 96.94 169.88 101.47 168.00 108.00 C 166.12 114.53 159.04 130.34 156.00 136.00 C 152.96 141.66 151.21 143.38 147.00 147.00 C 142.79 150.62 132.51 158.10 127.00 161.00 C 121.49 163.90 116.39 166.42 109.00 167.00 C 101.61 167.58 81.51 163.26 76.00 165.00 C 70.49 166.74 69.84 176.53 71.00 179.00 C 72.16 181.47 77.19 181.71 84.00 182.00 C 90.81 182.29 108.28 183.61 118.00 181.00 C 127.72 178.39 142.88 170.24 151.00 164.00 C 159.12 157.76 169.36 145.54 174.00 138.00 C 178.64 130.46 181.69 120.12 183.00 112.00 C 184.31 103.88 183.87 89.39 183.00 82.00 C 182.13 74.61 179.47 66.51 177.00 61.00 C 174.53 55.49 169.34 45.30 166.00 44.00 Z"/><circle cx="142.39" cy="29.62" r="15.39" fill="#0a43fe"/><circle cx="50.72" cy="162.82" r="15.43" fill="#0941fc"/></g><circle class="pr41-pet-eye-left" cx="62" cy="95.72" r="11.23" fill="#071638"/><circle class="pr41-pet-nose" cx="96.65" cy="95.72" r="11.26" fill="#081738"/><circle class="pr41-pet-eye-copper" cx="130.75" cy="95.64" r="11.28" fill="#f47a3c"/><path class="pr41-pet-smile" d="M 59 137 Q 96 160 133 137" pathLength="100" stroke="#071638" stroke-width="6" stroke-linecap="round" fill="none"/></svg>';

function currentKey(root){
  const title=(root.querySelector('[data-pr30-title]')?.textContent||'').trim().toLowerCase();
  if(title.includes('квиз')) return 'quiz';
  if(title.includes('crm')) return 'crm';
  if(title.includes('бот')) return 'bots';
  if(title.includes('ai')) return 'ai';
  if(title.includes('интеграц')) return 'integration';
  if(title.includes('автомат')) return 'automation';
  if(title.includes('152')) return 'law';
  return 'site';
}

function applyScene(root){
  const key=currentKey(root);
  root.dataset.pr45Scene = key;
  root.classList.add('pr45-animate');
}

function bootRoot(root){
  if(root.dataset.pr45Booted) return;
  root.dataset.pr45Booted='1';
  applyScene(root);
  let pet=root.querySelector('[data-pr41-pet]');
  if(!pet){
    pet=document.createElement('button');
    pet.type='button';
    pet.className='pr41-pet pr42-pet';
    pet.dataset.pr41Pet='';
    pet.setAttribute('aria-label','ИИ-пэт PRAMIO — подмигнуть');
    pet.setAttribute('title','ИИ-пэт PRAMIO');
    pet.innerHTML=SVG;
    root.appendChild(pet);
  }
  const reduced=window.matchMedia?.('(prefers-reduced-motion: reduce)');
  let timer=0, cooldown=0, debounce=0;
  const react=()=>{
    if(reduced?.matches) return;
    const now=Date.now();
    // R47: do not restart an unfinished smile. Let the nose, eyes and smile complete
    // their original keyframes and return to neutral before the next reaction.
    if(now-cooldown<1680 || pet.classList.contains('pr41-react')) return;
    cooldown=now;
    pet.classList.add('pr41-react');
    clearTimeout(timer);
    timer=window.setTimeout(()=>pet.classList.remove('pr41-react'),1595);
  };
  pet.addEventListener('click',e=>{e.stopPropagation();react()});
  root.addEventListener('pramio:pet-react',()=>react());
  const heading=root.querySelector('[data-pr30-title]');
  if(heading){
    const observer=new MutationObserver(()=>{
      clearTimeout(debounce);
      debounce=window.setTimeout(()=>{ applyScene(root); react(); },120);
    });
    observer.observe(heading,{childList:true,characterData:true,subtree:true});
  }
  window.setTimeout(()=>react(),900);
}

function boot(){document.querySelectorAll('.pr30-motion').forEach(bootRoot)}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot,{once:true});else boot();
if(!document.querySelector('.pr30-motion') && document.body){const late=new MutationObserver(()=>{if(document.querySelector('.pr30-motion')){late.disconnect();boot();}});late.observe(document.body,{childList:true,subtree:true});setTimeout(()=>late.disconnect(),10000);}
})();
