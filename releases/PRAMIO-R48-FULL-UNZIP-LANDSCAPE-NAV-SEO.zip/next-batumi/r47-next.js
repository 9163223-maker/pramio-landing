(()=>{'use strict';
  const root=document.documentElement,nav=document.getElementById('mobile-nav'),menu=document.querySelector('.menu-toggle'),dlg=document.getElementById('r47-form'),form=document.getElementById('r47-lead-form'),status=form?.querySelector('.r47-form-status'),submit=form?.querySelector('[type=submit]');
  const reduced=window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
  const setStatus=(text,state='')=>{if(status){status.textContent=text;status.className='r47-form-status '+state}};
  if(menu&&nav){menu.addEventListener('click',()=>{const open=menu.getAttribute('aria-expanded')!=='true';menu.setAttribute('aria-expanded',String(open));nav.hidden=!open;});nav.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>{nav.hidden=true;menu.setAttribute('aria-expanded','false')}));}
  if('IntersectionObserver' in window){const io=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting){e.target.classList.add('is-visible');io.unobserve(e.target)}}),{threshold:.12,rootMargin:'0px 0px -35px 0px'});document.querySelectorAll('.r47-reveal').forEach(el=>io.observe(el));}else{document.querySelectorAll('.r47-reveal').forEach(el=>el.classList.add('is-visible'));}
  if(!reduced){let ticking=false;const hero=document.getElementById('r47-hero');const update=()=>{if(hero){const y=Math.min(Math.max(window.scrollY,0),850);hero.style.setProperty('--r47-scroll-y',`${Math.round(y*.085)}px`)}ticking=false;};addEventListener('scroll',()=>{if(!ticking){requestAnimationFrame(update);ticking=true}},{passive:true});}
  let openedAt=0,opener=null,fetchPromise=null;
  async function fetchToken(){const res=await fetch('/send.php?form_token=1',{credentials:'same-origin',headers:{Accept:'application/json'},cache:'no-store'});const j=await res.json();if(!res.ok||!j.ok||!j.token)throw new Error('token_failed');form.elements.form_token.value=j.token;return j.token;}
  function openForm(){if(!dlg||!form)return;opener=document.activeElement;openedAt=Date.now();form.elements.started_at.value=String(openedAt);setStatus('Укажите контакты — ответ придёт на ваш e-mail.');if(!dlg.open)dlg.showModal();fetchPromise=fetchToken().catch(()=>{setStatus('Сервис временно недоступен. Попробуйте позже.','error');return null});fetchPromise.then(()=>{if(dlg.open)form.elements.client_name.focus({preventScroll:true})});}
  document.querySelectorAll('[data-open-form]').forEach(btn=>btn.addEventListener('click',e=>{e.preventDefault();openForm()}));
  document.querySelectorAll('[data-close-form]').forEach(btn=>btn.addEventListener('click',()=>dlg?.close()));
  if(dlg){dlg.addEventListener('click',e=>{if(e.target===dlg)dlg.close()});dlg.addEventListener('close',()=>{opener?.focus?.({preventScroll:true})});}
  if(!form)return;
  for(const field of form.querySelectorAll('input[required]'))field.addEventListener('input',()=>field.removeAttribute('aria-invalid'));
  form.addEventListener('submit',async e=>{
    e.preventDefault();
    if(submit?.disabled)return;
    let invalid=null;
    for(const field of form.querySelectorAll('input[required]')){const ok=field.checkValidity();field.toggleAttribute('aria-invalid',!ok);if(!ok&&!invalid)invalid=field;}
    if(invalid){setStatus('Проверьте имя, e-mail и согласие на обработку данных.','error');invalid.focus();return;}
    submit.disabled=true;setStatus('Проверяем и отправляем запрос…');
    try{
      const token=await (fetchPromise||fetchToken());if(!token)throw new Error('token_failed');
      const minTime=1500-(Date.now()-openedAt);if(minTime>0)await new Promise(r=>setTimeout(r,minTime+50));
      const name=form.elements.client_name.value.trim();const phone=form.elements.phone.value.trim();const email=form.elements.email.value.trim();const interest=form.elements.interest.value;
      form.elements.message.value=`Демо-тизер NEXT Batumi (PRAMIO R47)\nИмя: ${name}\nТелефон: ${phone||'не указан'}\nEmail: ${email}\nИнтерес: ${interest}\nИсточник: https://pramio.ru/next-batumi/\n\nДемонстрационная заявка для PRAMIO — не запрос отделу продаж NEXT.`;
      const res=await fetch('/send.php',{method:'POST',body:new FormData(form),credentials:'same-origin',headers:{Accept:'application/json'}});
      const data=await res.json().catch(()=>({}));if(!res.ok||data.ok!==true)throw new Error(data.error||'delivery_failed');
      form.reset();openedAt=Date.now();form.elements.started_at.value=String(openedAt);form.elements.form_token.value=data.token||'';fetchPromise=data.token?Promise.resolve(data.token):fetchToken();setStatus('Запрос доставлен PRAMIO. Ответим на ваш e-mail.','success');
      form.querySelectorAll('input:not([type=hidden]), select').forEach(field=>{field.disabled=true});submit.hidden=true;
    }catch(err){const code=err?.message||'';let text='Не удалось отправить запрос. Проверьте подключение и попробуйте ещё раз.';if(code==='request_rejected'||code==='token_failed')text='Не удалось проверить защитный токен. Закройте форму и откройте снова.';if(code==='rate_limited'||code==='too_fast')text='Слишком частые запросы. Попробуйте немного позже.';setStatus(text,'error');}
    finally{submit.disabled=false;}
  });
})();
