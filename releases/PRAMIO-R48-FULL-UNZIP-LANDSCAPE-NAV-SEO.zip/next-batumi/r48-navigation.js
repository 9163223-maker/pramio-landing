(()=>{'use strict';
 const slides=[...document.querySelectorAll('[data-r48-slide]')], header=document.querySelector('.site-header'), nav=document.querySelector('[data-r48-nav]');
 if(slides.length!==3||!nav)return;
 const prev=nav.querySelector('[data-r48-prev]'),next=nav.querySelector('[data-r48-next]'),counter=nav.querySelector('[data-r48-current]');
 const reduced=window.matchMedia?.('(prefers-reduced-motion: reduce)');
 let current=0,raf=0,gestureTarget=null;
 const headerH=()=>header?.getBoundingClientRect().height||0;
 function computeIndex(){const line=headerH()+Math.min(window.innerHeight*.26,110);let candidate=0;for(let i=0;i<slides.length;i++){if(slides[i].getBoundingClientRect().top<=line)candidate=i;}return candidate;}
 function render(){const i=computeIndex();current=i;counter.textContent=String(i+1).padStart(2,'0');prev.disabled=i===0;next.disabled=i===slides.length-1;nav.setAttribute('data-r48-active',String(i+1));}
 function go(i){const n=Math.min(slides.length-1,Math.max(0,i));const top=Math.max(0,Math.round(slides[n].getBoundingClientRect().top+window.scrollY-headerH()));current=n;window.scrollTo({top,behavior:reduced?.matches?'auto':'smooth'});counter.textContent=String(n+1).padStart(2,'0');prev.disabled=n===0;next.disabled=n===slides.length-1;}
 prev.addEventListener('click',()=>go(computeIndex()-1));
 next.addEventListener('click',()=>go(computeIndex()+1));
 document.querySelectorAll('[data-r48-go]').forEach(node=>node.addEventListener('click',e=>{const index=Number(node.getAttribute('data-r48-go'))-1;if(index>=0&&index<3){e.preventDefault();go(index)}}));
 addEventListener('scroll',()=>{if(!raf)raf=requestAnimationFrame(()=>{raf=0;render()})},{passive:true});
 addEventListener('resize',()=>{requestAnimationFrame(render)},{passive:true});
 document.addEventListener('keydown',e=>{if(e.defaultPrevented||e.ctrlKey||e.altKey||e.metaKey||document.querySelector('.r47-dialog[open]'))return;const t=e.target;if(t&&/^(INPUT|TEXTAREA|SELECT|BUTTON|A)$/.test(t.tagName))return;if(e.key==='PageDown'){e.preventDefault();go(computeIndex()+1)}else if(e.key==='PageUp'){e.preventDefault();go(computeIndex()-1)}});
 // iOS orientation: retain the active scene, rather than landing on a half screen after reflow.
 addEventListener('orientationchange',()=>{const target=current;setTimeout(()=>{go(target);render()},240)},{passive:true});
 render();
})();
