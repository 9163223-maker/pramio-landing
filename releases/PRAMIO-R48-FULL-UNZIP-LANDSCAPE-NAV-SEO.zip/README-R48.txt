PRAMIO R48 — FIX LANDSCAPE + SECTION NAVIGATION + CLICKABLE TAGS

INSTALLATION
1. Make a backup of Timeweb public_html first.
2. Open public_html and extract the ZIP CONTENTS directly there, choosing REPLACE (not Make copies).
3. No installer, PHP changes or manual linking.
4. The homepage remains / ; NEXT teaser at /next-batumi/ ; portfolio at /portfolio/.

WHAT CHANGED
- Next Batumi teaser: active 'ЛИСТАЙТЕ ВНИЗ' control, sticky up/down section rail showing 01/03, 02/03, 03/03; anchor jump fallback.
- Compact iPhone landscape layout; less wasted vertical space in story, cream ribbon and end section.
- No blue emoji square arrow on photographic caption; consistent SVG arrow icons.
- All eight hero capability labels on the PRAMIO homepage are functional SEO/internal links, with keyboard focus states.
- Existing R47 imagery, sound/pet animation, lead form and portfolio card are preserved.

IMPORTANT: this is an incremental update to already-installed R47. All altered code files are in the ZIP; existing R47 photo assets in next-batumi/assets/ must remain in public_html.

TEST
https://pramio.ru/?r=48
https://pramio.ru/next-batumi/?r=48
https://pramio.ru/portfolio/

STATUS: local static/interaction test only. Live Safari acceptance and actual server lead delivery require post-deploy check.
